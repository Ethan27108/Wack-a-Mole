"""
Wack a Mole
Ethan McLeod
June 16 2022
"""
#Basic imports
import pyglet
from pyglet import clock
import random
import time

#Setting base variables
window = pyglet.window.Window(756, 567)
window.score = 0
window.game_on = False
window.time = 40
window.end = False
window.hit = False
window.timestart = time.time()
moles = []

#Imports from other classes
from classes.hammer import Hammer
from classes.mole import Mole
from classes.redo import Redo

def molePlacement():
    """Places the mole in their proper spot and changes their colour"""
    for mole in moles:
                    xposition = random.randint(1,3)
                    yposition = random.randint(1,3)
                    mole.changecolour()
                    mole.x = -178 + 245*xposition
                    mole.y = -116 + 153*yposition

def playAgain():
    """Resets variables to base values"""
    window.score = 0
    window.time = 40
    window.game_on = False
    window.end = False
    redo.x = -500
    redo.y = -500
    end_label.text=('')

    #Resets the text screen
    score_label.text=("Score: "+ str(window.score))
    message_label.text = 'Hit as many moles as you can'
    point_label.text = 'Point system is:'
    colourpoint_label.text = 'red:-25, brown:2, blue:5,green:10, purple:20'
    time_label.text='Time remaining: ' + str(window.time)



@window.event
def on_draw():
    """clear the window and redraw all graphic objects"""
    window.clear()
    if window.end == True:
        back.draw()
        end_label.draw()
        redo.draw()
        mole.x = -500
        mole.y = -500
        redo.x = window.width//2
        redo.y = window.height//2

    else:
        back.draw()
        moles[0].draw()
        moles[1].draw()
        hammer.draw()
        time_label.draw()
        message_label.draw()
        colourpoint_label.draw()
        point_label.draw()
        score_label.draw()
        end_label.draw()



@window.event
def on_mouse_motion(x, y, dx, dy):
    """Makes the hammer image follow the mouse and can't go off screen"""
    hammer.x = x - 50
    hammer.y = y - 50
    hammer.stay_on_window()



@window.event
def on_mouse_release(x, y, button, mofifiers):
    """Turns the animation to false to ready it again"""
    hammer.turned = False



@window.event
def on_mouse_press(x, y, button, modifiers):
    """When the mouse is clicked it starts the game then checks to see if you pressed on a mole or the play again
    If on the play again it restarts the game
    If on the mole it awards points accordingly"""
    window.game_on = True
    message_label.text=''
    colourpoint_label.text=''
    point_label.text=''
    hammer.turned = True
    
    #If the redo button is there and is clicked it will start the game again
    if (redo.mouse_is_on(x, y)):
        playAgain()

    #Checks for the mole being hit and that it hasnt been hit before in this update
    for mole in moles:
        if (hammer.collides_with(mole)) & (window.hit == False):
            #Gives points depending on what colour of mole you hit 
            if mole.colour == 1:
                window.score -= 25
                score_label.text='Score: ' + str(window.score)
            elif mole.colour == 2:
                window.score += 2
                score_label.text='Score: ' + str(window.score)
            elif mole.colour == 3:
                window.score += 5
                score_label.text='Score: ' + str(window.score)
            elif mole.colour == 4:
                window.score += 10
                score_label.text='Score: ' + str(window.score)
            elif mole.colour == 5:
                window.score += 20
                score_label.text='Score: ' + str(window.score)
            #Sets a varaible true saying its already been hit so they cant just spam click the same mole
            window.hit = True
    

        
    
def update(dt):
    """Check to make sure the game is still on and the timer hasn't run out
    Then takes away a second from the time and randomly chooses postion and colours for both moles
    Puts both moles where they are postioned to be and changes their colours"""
    #checks to see if the timer has run out
    if int(window.time)<=0:
            window.end = True
            #Checks to see if they go a new highscore if so it tell them this and adds the number to a outer file for the next time they play
            file = open ("highscore.txt", "r")
            highscore = int(file.readline())
            newscore = int(window.score)
            if newscore > highscore:
                end_label.text=("You got a new high score of " + str(window.score) + ".")
                file = open("highscore.txt", "w")
                file.write(str(window.score))


    #Checks to make sure the game is on
    elif (window.game_on):
        #Checks the time to make sure the moles only update every second
        if (time.time() - window.timestart >= 1):
            #Lowers the time and sets the variables to being hit already false
            window.time -= 1
            window.hit = False
            time_label.text='Time remaining: ' + str(window.time)

            #Places the moles and makes sure they arent on the same spot
            molePlacement()
            while True:
                if (moles[0].x == moles[1].x) and (moles[0].y == moles[1].y):
                    molePlacement()
                else: 
                    break
            window.timestart = time.time()

    hammer.update(dt)
    



########## Main Program ##########

#Creates the redo button
redo = Redo('assets/playAgain.png',
                x = -500 , y = -500,)

#Creates the hammer 
hammer = Hammer('assets/hammer.png', 'assets/hammerTurned.png', window.width, window.height,
                x = window.width//2 , y = window.height//2,)

#Loads the background image then creates it and scales it
back_image = pyglet.image.load('assets/background.png')
back = pyglet.sprite.Sprite(back_image, x=0, y=0)
back.scale = 0.4

#Creates the message label for the start and sets the colour to black with full opacity
message_label = pyglet.text.Label(text="Hit as many moles as you can",
                                x=window.width//2, y=500, anchor_x='center')
message_label.color = (0, 0, 0, 255)

#Creates the point label for the start and sets the colour to black with full opacity
point_label = pyglet.text.Label(text="Point system is:",
                                x=window.width//2, y=475, anchor_x='center')
point_label.color = (0, 0, 0, 255)

#Creates the point explaining label for the start and sets the colour to black with full opacity
colourpoint_label = pyglet.text.Label(text="red:-25, brown:2, blue:5,green:10, purple:20",
                                x=window.width//2, y=450, anchor_x='center')  
colourpoint_label.color = (0, 0, 0, 255)                              

#Creates the score label and sets the colour to black with full opacity
score_label = pyglet.text.Label(text="Score: "+ str(window.score), 
                                x=window.width//2, y=550, anchor_x='center')
score_label.color = (0, 0, 0, 255)  

#Creates the timer and sets the colour to black with full opacity
time_label = pyglet.text.Label(text="Time remaining: "+ str(window.time) + " seconds", 
                                x=window.width//2, y=525, anchor_x='center')
time_label.color = (0, 0, 0, 255)  

#Creates the mole
for i in range(2):  
    mole = Mole('assets/brownMole.png',  window.width, window.height, 
            x=-500, y=-500)
    moles.append(mole)

#Creates the highscore label and sets the colour black 
end_label = pyglet.text.Label(text="", x=window.width//2, y=400, anchor_x='center')
end_label.color = (0, 0, 0, 255)

#Runs the pyglet window and updates it everyone second
pyglet.clock.schedule_interval(update, 1/120)
pyglet.app.run()