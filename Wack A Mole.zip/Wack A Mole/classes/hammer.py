"""
Wack a Mole hammer sprite
Ethan McLeod
June 16 2022
"""

#Imports
import pyglet
import time
import math


class Hammer(pyglet.sprite.Sprite):
    """ Hammer is a PhysicalObject with drag-and-drop functionality"""

    def __init__(self, sprite_img1, sprite_img2, bx, by, *args, **kwargs):
        """set up image and set x and y boundaries (max width/height)"""

        images = [pyglet.resource.image(sprite_img1), pyglet.resource.image(sprite_img2), pyglet.resource.image(sprite_img1)]
        self.sprite_image = pyglet.image.Animation.from_image_sequence(images, duration = 0.1, loop = False)
        
        self.sprite_image.manualwidth = self.sprite_image.get_max_width()
        self.sprite_image.manualheight = self.sprite_image.get_max_height()

        super().__init__(self.sprite_image, *args, **kwargs)
        self.center_image(self.sprite_image)
        self._xbound = bx
        self._ybound = by
        self.turned = False
        self.drag = False

    def mouse_is_on(self, x, y):
        """return True if x, y position is on top of calling object"""
        
        if (self.x - self.manualwidth//2 < x < self.x + self.manualwidth//2) and (self.y - self.manualheight//2 < x < self.y + self.manualheight//2):
            return True

        return False
    
    def center_image(self, image):
        """Sets an image's anchor point to its center"""
        image.anchor_x = image.manualwidth // 2
        image.anchor_y = image.manualheight // 2

    def stay_on_window(self):
        """ adjusts calling object's position to edge
        if mouse moves off window"""

        if self.y > self._ybound:      #top
            self.y = self._ybound
        if self.x > self._xbound:      #right
            self.x = self._xbound
        if self.y < 0:                          #bottom
            self.y = 0
        if self.x < 0:                          #left
            self.x = 0

    def distance(self, point_1=(0, 0), point_2=(0, 0)):
        return math.sqrt(
            (point_1[0] - point_2[0]) ** 2 +
            (point_1[1] - point_2[1]) ** 2)

    def collides_with(self, other_object):
        collision_distance = self.image.manualwidth/2 + other_object.image.width/2
        actual_distance = self.distance(self.position,other_object.position)

        
        return (actual_distance <= collision_distance)
    def update(self, dt):
        """Changes the image to animate the hammer swinging if the main program says to"""
        if self.turned == True:
            self.image = self.sprite_image