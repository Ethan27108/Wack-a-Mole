"""
Wack a Mole mole sprite
Ethan McLeod
June 16 2022
"""

#Imports
import pyglet
import random
from classes.physicalObject import PhysicalObject

#Loads all the images
red_image = pyglet.image.load('assets/redMole.png')
brown_image = pyglet.image.load('assets/brownMole.png')
blue_image = pyglet.image.load('assets/blueMole.png')
green_image = pyglet.image.load('assets/greenMole.png')
purple_image = pyglet.image.load('assets/purpleMole.png')

class Mole(PhysicalObject):
    
    def __init__(self, img_filename, bx, by, *args, **kwargs):
        """set up image and set y boundary (max height) and speed and sets the colours all to false to start"""

        super().__init__(img_filename, *args, **kwargs)

        self._xbound = bx            #private attribues
        self._ybound = by

    def mouse_is_on(self, x, y):
        """return True if x, y position is on top of calling object"""
        
        if (self.x - self.width//2 < x < self.x + self.width//2) and (self.y - self.height//2 < x < self.y + self.height//2):
            return True
        return False
    def changecolour(self):
        """Generates a random number than changes colour accordingly"""
        self.colour = random.randint(1,5)
        if self.colour == 1:
            self.image = red_image
            
        elif self.colour == 2:
            self.image = brown_image
            
        elif self.colour == 3:
            self.image = blue_image
            
        elif self.colour == 4:
            self.image = green_image
            
        elif self.colour == 5:
            self.image = purple_image

    