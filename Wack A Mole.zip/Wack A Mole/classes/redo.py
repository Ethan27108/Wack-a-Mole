"""
Wack a Mole redo button
Ethan McLeod
June 16 2022
"""
#Imports
import pyglet

class Redo(pyglet.sprite.Sprite):
    
    def __init__(self,  img_filename, *args, **kwargs):
        """set up image"""
        sprite_image = pyglet.resource.image(img_filename)
        self.center_image(sprite_image)
        super().__init__(sprite_image, *args, **kwargs)

    def center_image(self, image):
        """Sets an image's anchor point to its center"""
        image.anchor_x = image.width // 2
        image.anchor_y = image.height // 2

    def mouse_is_on(self, x, y):
        """return True if x, y position is on top of calling object"""
            
        if (self.x - self.width//2 < x < self.x + self.width//2) and (self.y - self.height//2 < y < self.y + self.height//2):
            return True
                
        return False